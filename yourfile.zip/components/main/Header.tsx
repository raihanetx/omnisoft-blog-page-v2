
import React from 'react';

const Header: React.FC = () => {
    return null;
};

export default Header;